Reminder: Change Permissions to 600

Always remember to change the permissions of sensitive files, such as SSH private keys, to 600 after creating or modifying them. This ensures that only the owner has read and write permissions, enhancing security.

To change permissions to 600, use the following command:

chmod 600 /path/to/file

Replace /path/to/file with the actual path to your file.
